# Contrast Audit Report — Portfolio

Date: 2026-02-21

Summary: this small report lists computed contrast ratios (WCAG) for key UI elements in both dark and light themes using the current CSS variables. Ratios rounded to two decimals. Pass thresholds: AA normal >= 4.5, AA large >= 3.0, AAA normal >= 7.0.

---

## Theme variables (selected)

- Dark theme (:root)
  - `--bg-primary` = #0d1117 (L ≈ 0.0055)
  - `--card-bg` / `--bg-secondary` = #0f1720 (L ≈ 0.0082)
  - `--text-primary` = #c9d1d9 (L ≈ 0.63)
  - `--text-heading` = #e6eef6 (L ≈ 0.847)
  - `--accent-primary` = #58a6ff (L ≈ 0.366)
  - `--accent-hover` = #79b8ff (L ≈ 0.455)
  - `--on-accent` = #ffffff (white) (L = 1.00)

- Light theme (`[data-theme="light"]`)
  - `--bg-primary` = #ffffff (L = 1.00)
  - `--text-primary` = #2d3748 (L ≈ 0.0378)
  - `--accent-primary` = #0066cc (L ≈ 0.139)
  - `--on-accent` = #ffffff (L = 1.00)

Notes: luminance values are approximate (sRGB linearized) and used to compute contrast ratios.

---

## Dark theme — element checks

| Element                                                                         |                   Foreground |               Background |           Contrast | WCAG |
| ------------------------------------------------------------------------------- | ---------------------------: | -----------------------: | -----------------: | ---: |
| Heading (h1-h6)                                                                 |   `--text-heading` (#e6eef6) | `--bg-primary` (#0d1117) |              16.17 |  AAA |
| Body text (p)                                                                   |   `--text-primary` (#c9d1d9) | `--bg-primary` (#0d1117) |              12.26 |  AAA |
| Link / Icon (normal)                                                            | `--accent-primary` (#58a6ff) |           `--bg-primary` |               7.49 |  AAA |
| Link / Icon (hover)                                                             |   `--accent-hover` (#79b8ff) |           `--bg-primary` |               9.11 |  AAA |
| Card heading                                                                    |   `--text-heading` (#e6eef6) |    `--card-bg` (#0f1720) |              15.41 |  AAA |
| Card body                                                                       |   `--text-primary` (#c9d1d9) |    `--card-bg` (#0f1720) |              11.68 |  AAA |
| Button (primary) — text `--on-accent` (#ffffff) on `--accent-primary` (#58a6ff) |            #ffffff / #58a6ff |                     2.53 | FAIL (needs >=4.5) |

**Issue:** primary-filled buttons in dark theme fail AA contrast for normal text (white on current accent). This is the single critical accessibility item found.

---

## Light theme — element checks

| Element                                                     |                   Foreground |               Background | Contrast | WCAG |
| ----------------------------------------------------------- | ---------------------------: | -----------------------: | -------: | ---: |
| Body text                                                   |   `--text-primary` (#2d3748) | `--bg-primary` (#ffffff) |    11.96 |  AAA |
| Heading (black)                                             |     `--text-heading` (black) | `--bg-primary` (#ffffff) |    21.00 |  AAA |
| Link                                                        | `--accent-primary` (#0066cc) | `--bg-primary` (#ffffff) |     5.56 |   AA |
| Button primary — white text on `--accent-primary` (#0066cc) |            #ffffff / #0066cc |                     5.56 |       AA |

All checked light-theme combinations pass AA for normal or large text as appropriate.

---

## Recommendations (actionable)

1. Fix primary button contrast in dark theme. Options:
   - Quick, minimal-change: set `--on-accent` in dark `:root` to a dark color (e.g. `#061826`) so text-on-accent becomes dark for filled buttons in dark mode. This yields contrast >= 4.5 for the current accent.
   - Preferred: darken `--accent-primary` slightly in dark theme so white text on accent meets 4.5. I can propose and test two alternates if you want: `#1f6feb` and `#2065d6` (I'll compute contrast and pick best visual match).
   - Alternative design: use outlined buttons (`.btn-secondary`) in dark mode instead of filled primary buttons.

2. Enhance keyboard focus visibility: keep the `:focus-visible` outline, but also ensure components (buttons/inputs/links) also show a higher-contrast focus ring (e.g., `box-shadow: 0 0 0 3px rgba(88,166,255,0.18)` + `border-color` change).

3. Update decorative SVGs / images referencing old cyan `#00d4ff` to the new accent (`--accent-primary`) for consistent branding.

---

## Next steps I can take for you

- Apply the minimal safe fix (set `--on-accent` dark in dark `:root`) now.
- Or, test/determine a darker `--accent-primary` variant for dark mode and update CSS + hover colors.
- Generate a machine-readable CSV (created alongside this MD file).

If you want me to apply a fix automatically, tell me which option you prefer.
