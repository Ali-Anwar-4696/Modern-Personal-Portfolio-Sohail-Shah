// Simple WCAG contrast checker for project's CSS variables
const fs = require("fs");
const path = require("path");

const cssPath = path.join(__dirname, "../css/style.css");
const css = fs.readFileSync(cssPath, "utf8");

function hexToRgb(hex) {
  hex = hex.replace("#", "");
  if (hex.length === 3)
    hex = hex
      .split("")
      .map((c) => c + c)
      .join("");
  const num = parseInt(hex, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}

function srgbToLinear(c) {
  c = c / 255;
  return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

function luminance(hex) {
  const [r, g, b] = hexToRgb(hex);
  return (
    0.2126 * srgbToLinear(r) +
    0.7152 * srgbToLinear(g) +
    0.0722 * srgbToLinear(b)
  );
}

function contrast(hex1, hex2) {
  const L1 = luminance(hex1);
  const L2 = luminance(hex2);
  const lighter = Math.max(L1, L2);
  const darker = Math.min(L1, L2);
  return (lighter + 0.05) / (darker + 0.05);
}

function parseVars(block) {
  const vars = {};
  const re = /--([a-z0-9-]+)\s*:\s*([^;]+);/gi;
  let m;
  while ((m = re.exec(block))) {
    vars[`--${m[1]}`] = m[2].trim();
  }
  return vars;
}

// Extract :root and [data-theme="light"] blocks
const rootMatch = css.match(/:root\s*{([\s\S]*?)}/i);
const lightMatch = css.match(/\[data-theme=\"light\"\]\s*{([\s\S]*?)}/i);

const rootVars = rootMatch ? parseVars(rootMatch[1]) : {};
const lightVars = lightMatch ? parseVars(lightMatch[1]) : {};

// Normalize values (only hex or rgba as fallback)
function resolveVar(val, themeVars) {
  val = val.trim();
  // var(--name)
  const varRe = /var\((--[a-z0-9-]+)\)/i;
  const m = val.match(varRe);
  if (m) {
    const name = m[1];
    // theme override
    if (themeVars && themeVars[name]) return normalizeColor(themeVars[name]);
    if (rootVars[name]) return normalizeColor(rootVars[name]);
    return val;
  }
  return normalizeColor(val);
}

function normalizeColor(v) {
  v = v.trim();
  // simple hex
  const hexRe = /#([0-9a-f]{3,6})/i;
  const m = v.match(hexRe);
  if (m) {
    let h = m[0];
    if (h.length === 4) {
      // #abc -> #aabbcc
      h = "#" + h[1] + h[1] + h[2] + h[2] + h[3] + h[3];
    }
    return h.toLowerCase();
  }
  // rgba -> convert to hex by blending with white/black? for now approximate if opaque
  const rgbaRe = /rgba?\(([^)]+)\)/i;
  const m2 = v.match(rgbaRe);
  if (m2) {
    const parts = m2[1].split(",").map((s) => s.trim());
    const r = Math.round(parseFloat(parts[0]));
    const g = Math.round(parseFloat(parts[1]));
    const b = Math.round(parseFloat(parts[2]));
    return rgbToHex(r, g, b);
  }
  return v; // fallback
}

function rgbToHex(r, g, b) {
  return (
    "#" +
    [r, g, b]
      .map((x) => {
        const s = x.toString(16);
        return s.length === 1 ? "0" + s : s;
      })
      .join("")
      .toLowerCase()
  );
}

// Pairs to check
const pairs = [
  { name: "Body text", fg: "--text-primary", bg: "--bg-primary" },
  { name: "Headings", fg: "--text-heading", bg: "--bg-primary" },
  { name: "Navbar links", fg: "--text-primary", bg: "--bg-secondary" },
  {
    name: "Hero title",
    fg: "--text-heading",
    bgStops: ["--bg-secondary", "--bg-tertiary"],
  },
  {
    name: "Hero subtitle",
    fg: "--accent-primary",
    bgStops: ["--bg-secondary", "--bg-tertiary"],
  },
  { name: "Project title", fg: "--text-heading", bg: "--bg-secondary" },
  { name: "Project description", fg: "--text-secondary", bg: "--bg-secondary" },
  { name: "Contact form text", fg: "--text-primary", bg: "--bg-primary" },
  { name: "Form labels", fg: "--text-heading", bg: "--bg-primary" },
  { name: "Buttons primary", fg: "--on-accent", bg: "--accent-primary" },
  { name: "Secondary button hover", fg: "--on-accent", bg: "--accent-primary" },
  { name: "Social link (hover)", fg: "--on-accent", bg: "--accent-primary" },
  { name: "Info box text", fg: "--text-secondary", bg: "--bg-primary" },
  { name: "Project overlay text", fg: "--on-accent", bg: "--overlay" },
];

function checkTheme(themeName, themeVars) {
  console.log("\nChecking theme:", themeName);
  let failCount = 0;
  for (const p of pairs) {
    const fgVal = resolveVar(`var(${p.fg})`, themeVars);
    if (!fgVal) {
      console.warn("Missing fg", p.fg);
      continue;
    }
    if (p.bg) {
      const bgVal = resolveVar(`var(${p.bg})`, themeVars);
      if (!bgVal) {
        console.warn("Missing bg", p.bg);
        continue;
      }
      const ratio = contrast(fgVal, bgVal);
      const ok = ratio >= 4.5;
      console.log(
        `${p.name}: ${fgVal} on ${bgVal} -> ${ratio.toFixed(2)} ${ok ? "OK" : "FAIL"}`,
      );
      if (!ok) failCount++;
    } else if (p.bgStops) {
      let worst = Infinity;
      let worstStop = null;
      for (const stop of p.bgStops) {
        const stopVal = resolveVar(`var(${stop})`, themeVars);
        const ratio = contrast(fgVal, stopVal);
        if (ratio < worst) {
          worst = ratio;
          worstStop = stopVal;
        }
      }
      const ok = worst >= 4.5;
      console.log(
        `${p.name}: ${fgVal} on gradient stops -> ${worst.toFixed(2)} (worst: ${worstStop}) ${ok ? "OK" : "FAIL"}`,
      );
      if (!ok) failCount++;
    }
  }
  return failCount;
}

const darkVars = rootVars;
const lightThemeVars = Object.assign({}, rootVars, lightVars);

let totalFails = 0;
totalFails += checkTheme("dark (root)", darkVars);
totalFails += checkTheme('light (data-theme="light")', lightThemeVars);

console.log("\nTotal failing pairs:", totalFails);
process.exit(totalFails > 0 ? 1 : 0);
