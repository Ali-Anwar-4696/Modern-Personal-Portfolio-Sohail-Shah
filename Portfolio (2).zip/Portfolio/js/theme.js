/**
 * theme.js - REMOVED
 *
 * Dark mode functionality has been completely removed from this portfolio.
 * The website now uses only the light theme for a clean, professional appearance.
 *
 * Removed features:
 * - Dark/Light mode toggle button
 * - Theme switching logic
 * - localStorage theme persistence
 * - Theme transition animations
 * - Meta theme-color dynamic updates
 *
 * CSS color variables now default to light theme only.
 * See css/style.css for the light theme color definitions.
 */
